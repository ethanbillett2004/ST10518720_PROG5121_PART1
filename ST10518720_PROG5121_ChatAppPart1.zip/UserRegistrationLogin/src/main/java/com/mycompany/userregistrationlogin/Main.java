package com.mycompany.userregistrationlogin;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // Scanner object to read user input from keyboard
        Scanner input = new Scanner(System.in);

        // Create Login object to access validation and login methods
        Login login = new Login();

        // ================= USERNAME SECTION =================
        String username;

        // Loop until a valid username is entered
        while (true) {
            System.out.print("Enter username(5 Characters long including an '_'): ");
            username = input.nextLine();

            // Call method to check username rules
            if (login.checkUsername(username)) {
                break; // Exit loop if valid
            } else {
                System.out.println("Invalid username! Must contain '_' and be max 5 characters.");
            }
        }

        // ================= PASSWORD SECTION =================
        String password;

        // Loop until valid password is entered
        while (true) {
            System.out.print("Enter password(must be 8+ characters with Capital letter , number and special symbol): ");
            password = input.nextLine();

            // Check password requirements
            if (login.checkPassword(password)) {
                break; // Exit loop if valid
            } else {
                System.out.println("Invalid password! Must be 8+ chars with capital, number & symbol.");
            }
        }

        // ================= PHONE SECTION =================
        String phone;

        // Loop until valid South African phone number is entered
        while (true) {
            System.out.print("Enter SA phone number(+27 or 0): ");
            phone = input.nextLine();

            // Validate phone number format
            if (login.checkPhone(phone)) break;

            System.out.println("Invalid SA phone number! Format: 0821234567 or +27821234567\n");
        }

        // ================= REGISTRATION =================
        // Only runs after all inputs are valid
        login.register(username, password, phone);

        System.out.println("\nRegistration successful!\n");

        // ================= LOGIN SECTION =================
        boolean isLoggedIn = false;

        // Keep asking until user logs in successfully
        //This loop will keep running while the user is NOT logged in
        while (!isLoggedIn) {
            System.out.print("Login username: ");
            String loginUser = input.nextLine();

            System.out.print("Login password: ");
            String loginPass = input.nextLine();

            // Check if login details match stored details
            if (login.loginUser(loginUser, loginPass)) {  //This line checks if the username and password entered by the user are correct
                System.out.println("Login successful!");
                isLoggedIn = true; // Exit loop
            } else {
                System.out.println("Login failed!");
            }
        }
    }
}