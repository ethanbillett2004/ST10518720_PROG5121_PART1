package com.mycompany.userregistrationlogin;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    // Create Login object for testing
    Login login = new Login();

    // ================= USERNAME TESTS =================
    @Test
    public void testValidUsername() {
        assertTrue(login.checkUsername("kyl_1")); // Should pass
    }

    @Test
    public void testInvalidUsername() {
        assertFalse(login.checkUsername("kyle!!!!!")); // Should fail
    }

    // ================= PASSWORD TESTS =================
    @Test
    public void testValidPassword() {
        assertTrue(login.checkPassword("Ch&&sec@ke99!"));     
    }

    @Test
    public void testInvalidPassword() {
        assertFalse(login.checkPassword("password")); // No uppercase, number, symbol
    }

    // ================= PHONE TESTS =================
    @Test
    public void testValidPhoneNumber() {
        assertTrue(login.checkPhone("+27831234567"));
    }

    @Test
    public void testInvalidPhoneNumber() {
        assertFalse(login.checkPhone("123456"));
    }

    // ================= REGISTRATION TEST =================
    @Test
    public void testSuccessfulRegistration() {
        boolean result = login.register("ab_cd", "Password1!", "+27831234567");
        assertTrue(result);
    }

    // ================= LOGIN TESTS =================
    @Test
    public void testSuccessfulLogin() {
        login.register("ab_cd", "Password1!", "+27831234567");
        assertTrue(login.loginUser("ab_cd", "Password1!"));
    }

    @Test
    public void testFailedLogin() {
        login.register("ab_cd", "Password1!", "+27831234567");
        assertFalse(login.loginUser("ab_cd", "WrongPass1!"));
    }
}